Type "make" to compile necessary programs.

I tested sample input given by running the command:
	./locationupdater < finalInput.txt 

I tested programs individually as well with many inputs.

